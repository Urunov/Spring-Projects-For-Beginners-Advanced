package uz.openAPI.model.users;

import lombok.Data;

@Data
public class SingleUser {
    //
    private DataAPI data;
    private SupportAPI support;
}
